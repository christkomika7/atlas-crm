# Backup Atlas CRM

Créé le: 2026-01-07T15:12:50.960Z

## Structure du backup

- **database/** : Contient tous les exports CSV de la base de données
- **uploads/** : Contient tous les fichiers uploadés par les utilisateurs
- **meta.json** : Métadonnées du backup

## Tables exportées (5)

- company.csv
- user.csv
- profile.csv
- supplier.csv
- client.csv
- appointment.csv
- contract.csv
- billboard.csv
- invoice.csv
- purchaseOrder.csv
- quote.csv
- deliveryNote.csv
- recurrence.csv
- payment.csv
- item.csv
- project.csv
- task.csv
- taskStep.csv
- city.csv
- area.csv
- billboardType.csv
- displayBoard.csv
- structureType.csv
- lessorType.csv
- documentModel.csv
- receipt.csv
- dibursement.csv
- source.csv
- fiscalObject.csv
- transactionCategory.csv
- transactionNature.csv
- allocation.csv
- deletion.csv
- notification.csv
- notificationRead.csv
- dibursementData.csv
- permission.csv
- session.csv
- account.csv
- verification.csv
- rateLimit.csv
- productService.csv

## Total d'enregistrements: 21

## Restauration

Pour restaurer ce backup:
1. Importer les fichiers CSV dans une base de données PostgreSQL
2. Copier le dossier uploads/ vers le répertoire de l'application
3. Vérifier l'intégrité des données avec meta.json
